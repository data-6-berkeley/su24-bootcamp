test = {   'name': 'q5a',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> calculate_supply(80, 1) == 365\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> calculate_supply(80, 2) == 730\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> calculate_supply(36, 3) == 49275\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
