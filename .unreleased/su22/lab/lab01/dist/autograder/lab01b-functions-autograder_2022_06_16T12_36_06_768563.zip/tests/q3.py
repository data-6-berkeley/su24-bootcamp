test = {   'name': 'q3',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> calculate_dog_age(1) == 7\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> calculate_dog_age(0.5) == 3.5\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> calculate_dog_age(12) == 84\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
