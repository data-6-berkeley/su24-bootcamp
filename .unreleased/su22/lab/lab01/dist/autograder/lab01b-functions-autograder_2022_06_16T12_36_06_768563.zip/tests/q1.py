test = {   'name': 'q1',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> ilovedata() == "I love Data Science!"\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(ilovedata()) == len("I love Data Science!")\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
