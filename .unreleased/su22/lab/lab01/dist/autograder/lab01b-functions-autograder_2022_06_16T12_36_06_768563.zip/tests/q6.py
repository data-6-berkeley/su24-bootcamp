test = {   'name': 'q6',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> both_positive(-1, 1) == False\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> both_positive(1, 1) == True\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
