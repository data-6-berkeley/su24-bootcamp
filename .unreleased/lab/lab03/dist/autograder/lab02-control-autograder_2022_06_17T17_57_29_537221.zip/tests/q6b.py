test = {   'name': 'q6b',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> wears_jacket_single_line(90, False) == False\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> wears_jacket_single_line(40, False) == True\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> wears_jacket_single_line(100, True) == True\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
