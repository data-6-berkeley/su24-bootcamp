test = {   'name': 'q7',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> greater_num(45, 10) == 45\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> greater_num(-1, 30) == 30\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> greater_num(20, 20) == 20\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
