test = {   'name': 'q6a',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> wears_jacket(90, False) == False\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> wears_jacket(40, False) == True\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> wears_jacket(100, True) == True\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
