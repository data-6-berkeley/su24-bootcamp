test = {   'name': 'q8',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> hello_world("en") == \'Hello, World\'\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> hello_world("es") == \'Hola, Mundo\'\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> hello_world("pt") == \'Olá, Mundo\'\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
