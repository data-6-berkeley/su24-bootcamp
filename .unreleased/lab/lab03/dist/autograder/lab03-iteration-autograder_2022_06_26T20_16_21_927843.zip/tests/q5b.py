test = {   'name': 'q5b',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> add_in_range_arange(3, 5) == 12\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> add_in_range_arange(1, 10) == 55\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
