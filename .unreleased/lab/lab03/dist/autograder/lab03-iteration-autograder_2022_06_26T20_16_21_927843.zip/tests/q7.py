test = {   'name': 'q7',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> sum_digits(10) == 1\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> sum_digits(4224) == 12\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> sum_digits(1234567890) ==  45\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
