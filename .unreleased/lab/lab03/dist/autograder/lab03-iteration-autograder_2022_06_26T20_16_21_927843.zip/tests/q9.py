test = {   'name': 'q9',
    'points': 2,
    'suites': [   {   'cases': [{'code': '>>> is_prime(10) == False\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> is_prime(7) == True\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
